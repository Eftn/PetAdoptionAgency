""" This models a pet potentially available for adoption"""
from flask_sqlalchemy import SQLAlchemy

DEFAULT_IMAGE ="https://www.bing.com/th?id=OIP.YxszQYAJBw_dXaCiRcd90wHaEA&w=183&h=100&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2"

db= SQLAlchemy()

class Pet(db.Model):
    """Pets available for adoption"""
    __tablename__="pets"

    id= db.Column(db.Integer, primary_key=True)
    name= db.Column(db.Text, nullable=False)
    species = db.Column(db.Text, nullable=False)
    photo_url = db.Column(db.Text)
    age= db.Column(db.Integer)
    notes = db.Column(db.Text)
    available= db.Column(db.Boolean, nullable=False, default=True)

    def image(self):
        """ Return image for pet"""
        return self.photo_url or DEFAULT_IMAGE


def connect_db(app):
    """Connect this database to provided Flask app.

    You should call this in your Flask app.
    """

    db.app = app
    db.init_app(app)